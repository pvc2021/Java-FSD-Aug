package com.pradeep.cms;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;


@ComponentScan(basePackages = {"com"})
@Configuration
public class CmsConfg {

	public CmsConfg() {
	System.out.println("===CmsConfg created====");
	}
	
}

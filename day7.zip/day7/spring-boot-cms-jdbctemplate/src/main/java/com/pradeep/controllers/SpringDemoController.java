package com.pradeep.controllers;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@RequestMapping("/spring")
@Controller
public class SpringDemoController {

	public SpringDemoController() {
		System.out.println("==========SpringDemoController created============");
	}

	@RequestMapping("/hello")
	public String hello() {
		return "hello";
	}

	@RequestMapping(value = "/welcome", method = RequestMethod.GET)
	public String welcome() {
		return "welcome";
	}

	@GetMapping("/greet")
	public ModelAndView greet() {
		return new ModelAndView("greet", "message", "Practice makes man perfect");
	}

	@ResponseBody
	@GetMapping("/today")
	public String today() {
		return "Today is " + new Date();
	}

}

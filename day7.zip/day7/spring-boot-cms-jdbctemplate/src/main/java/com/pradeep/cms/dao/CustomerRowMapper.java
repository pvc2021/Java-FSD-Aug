package com.pradeep.cms.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;

import org.springframework.jdbc.core.RowMapper;

import com.pradeep.cms.domain.Customer;

public class CustomerRowMapper implements RowMapper<Customer> {

	public CustomerRowMapper() {
		System.out.println("================CustomerRowMapper created==========");
	}

	@Override
	public Customer mapRow(ResultSet rs, int arg1) throws SQLException {

		System.out.println("============In mapRow method===========");
		Customer c = new Customer();
		c.setCustomerId(rs.getInt(1));
		c.setName(rs.getString(2));
		c.setPan(rs.getString(3));
		c.setMobile(rs.getString(4));
		c.setEmail(rs.getString("email"));
		c.setAddress(rs.getString("address"));
		c.setDob(rs.getDate(7));

		return c;
	}

}

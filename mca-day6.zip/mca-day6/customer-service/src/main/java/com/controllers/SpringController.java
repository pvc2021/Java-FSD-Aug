package com.controllers;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SpringController {

	
	@Autowired	
	private RestTemplate restTemplate;	

	Logger logger=Logger.getLogger("com.controllers.SpringController");

	public SpringController() {
	System.out.println("========Spring Controller created==========");
	}
	
	
	@GetMapping("/")
	public String index() {
		return "Hi all,Welcome to Spring Boot application";
	}
	
	@GetMapping("/hi")
	public String hello() {
		return "Hi all,Welcome to Spring Boot application";
	}
	
	@GetMapping("/welcome1")
	public String welcome() {
		return "Welcome to Spring Boot application";
	}
	
	
	@GetMapping("/error")
	public String error() {
		return "We are facing some issue Sorry for inconvinence";
	}
	
	

	@GetMapping("/getproductsfromotherservice")
	public String getProductsFromOtherService() {
		logger.info("#####Customer Service calling ProductsService getAllProducts method#############");
		return restTemplate.getForObject("http://localhost:1111/api/product-microservice/products",String.class);
	} 
	
	
	@GetMapping("/getproductfromotherservice/{productId}")
	public String getProductsFromOtherService(@PathVariable("productId")int productId) {
		logger.info("#####Customer Service calling ProductsService getProductById method#############");
		return restTemplate.getForObject("http://localhost:1111/api/product-microservice/products/"+productId,String.class);
	} 
	
}

package com.pradeep;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class DemoExceptionController {

	
	@ExceptionHandler(ArithmeticException.class)
	public String genericException(ArithmeticException exception) {
		System.out.println("In genericException");
		return exception.toString();
		
	}
	
}

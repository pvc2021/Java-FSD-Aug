package com.pradeep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.util.ErrorHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@SpringBootApplication
@RestController

public class SpringBootCmsAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCmsAppApplication.class, args);
	}
	
	

	@GetMapping("/")
	public String index() {
		
		return "Index Page";
	}
	

	
	@GetMapping("/hi")
	public String hi() {
		
		return "Hi Page";
	}
	
	@GetMapping("/welcome")
	public String welcome() {
		int a=100/0;
		
		return "Welcome Page";
	}
	
	
	
	
	@GetMapping("/data/{name}")
	public String getData(@PathVariable("name") String name) {
		
		if(!name.equals("Pradeep"))
		throw new RuntimeException("Plz provide valid name");
					
		return "Hi "+name+", Welcome to Page";
	}
	
	
	
}

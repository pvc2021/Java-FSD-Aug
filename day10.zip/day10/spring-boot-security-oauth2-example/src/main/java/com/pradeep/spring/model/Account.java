package com.pradeep.spring.model;

import java.io.Serializable;
import java.util.Date;
import java.util.Random;

public class Account implements Serializable {

	private int accno;
	private String name;
	private double balance;
	private Date doc;
	private String email;
	private String mobile;
	private String pan;
	private String address;
	
	public Account() {
	
	}
	
	public void setAccno(int accno) {
		this.accno = accno;
	}

	public int getAccno() {
		return accno;
	}

	public String getName() {
		return name;
	}

	public double getBalance() {
		return balance;
	}

	public Date getDoc() {
		return doc;
	}

	public void setDoc(Date doc) {
		this.doc = doc;
	}
	
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public String getEmail() {
		return email;
	}

	public String getMobile() {
		return mobile;
	}

	public String getPan() {
		return pan;
	}

	public String getAddress() {
		return address;
	}

	public Account(String name, double balance, String email, String mobile, String pan, String address) {
		this.accno = new Random().nextInt(100000);
		this.name = name;
		this.balance = balance;
		this.email = email;
		this.mobile = mobile;
		this.pan = pan;
		this.doc = new Date();
		this.address = address;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean withdraw(double amount) {
		this.balance = balance - amount;
		System.out.println("Account  " + accno + " is debited by Rs :" + amount + "/-");
		System.out.println("Total balance " + balance + "/-");
		return true;
	}

	public boolean deposit(double amount) {
		this.balance = balance +amount;
		System.out.println("Account  " + accno + " is credited by Rs :" + amount + "/-");
		System.out.println("Total balance " + balance + "/-");
		return true;
	}
	
	public void setEmail(String email) {
		this.email = email;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public void setPan(String pan) {
		this.pan = pan;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	@Override
	public String toString() {
		return "Account [accno=" + accno + ", name=" + name + ", balance=" + balance + ", doc=" + doc + ", email="
				+ email + ", mobile=" + mobile + ", pan=" + pan + ", address=" + address + "]";
	}
	
	

}

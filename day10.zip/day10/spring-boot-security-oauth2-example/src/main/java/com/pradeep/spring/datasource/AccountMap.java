package com.pradeep.spring.datasource;

import java.util.HashMap;
import java.util.Map;

import com.pradeep.spring.model.Account;

public enum AccountMap {
	INSTANCE;

	private Map<Integer, Account> map;

	private AccountMap() {
		map = new HashMap<>();
		Account a1 = new Account("ram patil", 34567.88834, "ram_patil@gmail.com", "7876262727", "BMXPC9856G", "PUNE");
		Account a2 = new Account("pradeep chinchole", 34567.88834, "pradeep_chinchole@gmail.com", "8876262727", "MMXPC9856A", "PUNE");
		Account a3 = new Account("sachin tendulkar", 34567.88834, "sachin_tendulkar@yahoo.com", "9276262727", "PMXPC9856G", "PUNE");
		Account a4 = new Account("mahesh kulkarni", 34567.88834, "mahesh_kulkarni@syntelinc.com", "9176262727", "CMXPC9856Y", "PUNE");
		Account a5 = new Account("ameay joshi", 34567.88834, "ameay_joshi@rediffmail.com", "7776262727", "DMXPC9856A", "PUNE");
	
		map.put(a1.getAccno(),a1);
		map.put(a2.getAccno(),a2);
		map.put(a3.getAccno(),a3);
		map.put(a4.getAccno(),a4);
		map.put(a5.getAccno(),a5);
			
	
	}
	
	public Map<Integer, Account> getMap() {
		return map;
	}

}

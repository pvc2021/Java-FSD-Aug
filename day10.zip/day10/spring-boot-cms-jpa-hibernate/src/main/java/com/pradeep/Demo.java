package com.pradeep;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class Demo {
public static void main(String[] args) {
	
	BCryptPasswordEncoder bc=new BCryptPasswordEncoder();
	
	System.out.println(bc.encode("RAM"));
	System.out.println(bc.encode("RAHIM"));
	System.out.println(bc.encode("DAVID"));
	
	
}
}

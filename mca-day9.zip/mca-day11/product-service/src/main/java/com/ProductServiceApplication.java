package com;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.productservice.dao.ProductRepository;
import com.pradeep.productservice.domain.Product;



@RestController
@SpringBootApplication
public class ProductServiceApplication implements CommandLineRunner {


	
	
	@Autowired
	ProductRepository repository;
	
	@Value("${server.port:1111}")	
	int port;	
		
	
	@Value("${info.version:1}")	
	String info;	
		
		
	public static void main(String[] args) {
		SpringApplication.run(ProductServiceApplication.class, args);
	}
	
	
	

	
	  @GetMapping("/")
		public String getProducts() {
			return "Product Service runnig at port   ["+port+"] and version is :"+info;
		}
	
	@Override
	public void run(String... args) throws Exception {
	System.out.println("=============Executing SQL Script====================");

	repository.save(new Product(null,"LG",11000.00));
	repository.save(new Product(null,"SONY",12000.00));
	repository.save(new Product(null,"SAMSUNG",13000.00));
	repository.save(new Product(null,"NOKIA",14000.00));
		
	}
}

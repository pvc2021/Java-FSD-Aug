
Build the Image
===================
docker build -t pradeepch82/product-microservice:1.1 .


Pass h2 database details
===========================

docker run --name product --env RDS_URL=jdbc:h2:mem:pradeepdb --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_USERNAME=sa --env RDS_PASSWORD=password --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/product-microservice:1.1


Pass MySQL database details
===========================

docker run --name p-mysql -e MYSQL_DATABASE=company -e MYSQL_USER=pradeep -e MYSQL_PASSWORD=pradeep -e MYSQL_ROOT_PASSWORD=admin -e -d mysql:5.6


docker network inpsect bridge

find ip address of p-mysql container

It this case :172.17.0.2


docker run --name product --env RDS_URL=jdbc:mysql://172.17.0.2:3306/company --env RDS_DRIVER_CLASS=com.mysql.cj.jdbc.Driver --env RDS_USERNAME=pradeep --env RDS_PASSWORD=pradeep --env RDS_DIALECT=org.hibernate.dialect.MySQL8Dialect -p 8080:8080 pradeepch82/product-microservice:1.1




docker run --name product --env RDS_URL=jdbc:mysql://172.17.0.2:3306/company --env RDS_DRIVER_CLASS=com.mysql.jdbc.Driver --env RDS_USERNAME=pradeep --env RDS_PASSWORD=pradeep --env RDS_DIALECT=org.hibernate.dialect.MySQL5Dialect -p 8080:8080 pradeepch82/product-microservice:1.1


To go inside the 

docker exec -it p-mysql bash
mysql -upradeep -ppradeep  or mysql -uroot -padmin






arn:aws:ssm:us-east-1:508712564996:parameter/RDS_URL
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_DRIVER_CLASS

arn:aws:ssm:us-east-1:508712564996:parameter/RDS_DIALECT
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_USERNAME
arn:aws:ssm:us-east-1:508712564996:parameter/RDS_PASSWORD

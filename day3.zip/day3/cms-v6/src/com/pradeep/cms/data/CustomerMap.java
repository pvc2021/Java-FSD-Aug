package com.pradeep.cms.data;

import java.text.ParseException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pradeep.cms.domain.Customer;

public enum CustomerMap {

	INSTANCE;

	private Map<Integer, Customer> map;

	private CustomerMap() {

		map = new HashMap<Integer, Customer>();
		try {

			Customer c1 = new Customer("Pradeep Chinchole", "pxmdp9845f", "91576525262", "pradeepch82@gmail.com",
					"Pune", "11-11-2011");
			Customer c2 = new Customer("Amol Chinchole", "pxmdp9845f", "71576525262", "amol@gmail.com", "Pune",
					"11-11-2011");
			Customer c3 = new Customer("Mahesh Chinchole", "pxmdp9845f", "81576525262", "mahesh@gmail.com", "Pune",
					"11-11-2011");
			Customer c4 = new Customer("Vishal Chinchole", "pxmdp9845f", "91576525262", "vishal@gmail.com", "Mumbai",
					"11-11-2011");

			map.put(c1.getCustomerId(), c1);
			map.put(c2.getCustomerId(), c2);
			map.put(c3.getCustomerId(), c3);
			map.put(c4.getCustomerId(), c4);

		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public Map<Integer, Customer> getMap() {
		return map;
	}
}

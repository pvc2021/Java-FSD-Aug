package com.pradeep.cms.presnetation;

import java.text.ParseException;
import java.util.Scanner;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

import com.mysql.jdbc.Driver;
import com.pradeep.cms.CmsConfg;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.ICustomerService;

@Controller
//@Component("customerMainApp")
public class CustomerMainApp {

	@Autowired
	// Dependency
	private ICustomerService cs;

	public CustomerMainApp() {
		System.out.println("===========CustomerMainApp default constructor=========");

	}

	/*
	 * @Autowired //byType //Constructor Injection public
	 * CustomerMainApp(ICustomerService cs) { this.cs = cs;
	 * System.out.println("===========CustomerMainApp param constructor=========");
	 * 
	 * }
	 * 
	 * 
	 * 
	 * 
	 * //setter Injection public void setCs(ICustomerService cs) { this.cs = cs;
	 * System.out.println("===========CustomerMainApp setCs =========");
	 * 
	 * }
	 */
	public void addCustomer(Customer customer) {

		if (cs.saveCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] created successfully");
		else
			System.out.println("Problem In adding customer");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] updated successfully");
		else
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] deoesn't exist");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with Id [" + customerId + "] deleted successfully");
		else
			System.out.println("Customer with Id [" + customerId + "] deoesn't exist");

	}

	public void showCustomer(int customerId) {

		Customer customer = cs.findCustomer(customerId);

		if (customer != null)
			System.out.println("Customer with Id [" + customerId + "] Details \n\n" + customer);
		else
			System.out.println("Customer with Id [" + customerId + "] deoesn't exist");

	}

	public void showAllCustomers() {
		System.out.println("=================Customer Details====================");
		System.out.println("=====================================================");

		for (Customer c : cs.findAllCustomers())
			System.out.println(c);

	}

	@PostConstruct
	public void myInit() {
		System.out.println("==========CustomerMainApp init method================");
	}

	@PreDestroy
	public void myDestory() {
		System.out.println("==========CustomerMainApp destory method================");
	}

	public static void main(String[] args) throws ParseException {

	
		int choice = 0;
		Scanner sc = new Scanner(System.in);
		ClassPathXmlApplicationContext c = new ClassPathXmlApplicationContext("beans-jdbc.xml");
		System.out.println("Spring  container created");
		CustomerMainApp cma = (CustomerMainApp) c.getBean("customerMainApp");

		while (choice <7) {
			System.out.println("=======================================================");
			System.out.println("Spring -Customer -MySQL -CRUD Application==============");
			System.out.println("=======================================================");
			System.out.println("Select below operations");
			System.out.println("=======================================================");
			System.out.println("1.ADD CUSTOMER");
			System.out.println("2.GET CUSTOMER");
			System.out.println("3.GET ALL CUSTOMERS");
			System.out.println("4.UPDATE CUSTOMER MOBILE AND ADDRESS");
			System.out.println("5.DELETE CUSTOMER");
			System.out.println("6.EXIT");
			System.out.println("Enter Choice");
			choice = sc.nextInt();
			switch (choice) {
			case 1:
				System.out.println("Enter Name,Pan,Mobile,Email,Address,Dob(dd-MM-yyyy)");
				Customer customer = new Customer(sc.next(), sc.next(), sc.next(), sc.next(), sc.next(), sc.next());
				cma.addCustomer(customer);

				break;
			case 2:
				System.out.println("Enter Customer Id :");
				cma.showCustomer(sc.nextInt());

				break;
			case 3:
				cma.showAllCustomers();
				break;
			case 4:
				System.out.println("Enter Customer Id, Mobile and Address ");
				Customer customer1 = new Customer();
				customer1.setCustomerId(sc.nextInt());
				customer1.setMobile(sc.next());
				customer1.setAddress(sc.next());

				cma.updateCustomer(customer1);

				break;
			case 5:
				System.out.println("Enter Customer Id :");
				cma.deleteCustomer(sc.nextInt());

				break;

			default:
				// shutdown the container
				c.registerShutdownHook();
				return;
				
			}

		}

		

	}
}

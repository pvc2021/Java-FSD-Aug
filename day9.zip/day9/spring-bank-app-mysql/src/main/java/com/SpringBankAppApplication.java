package com;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.pradeep.bank.dao.AccountDao;
import com.pradeep.bank.model.Account;

@SpringBootApplication
public class SpringBankAppApplication  implements CommandLineRunner{

	@Autowired
	private AccountDao accountDao;
	
	public static void main(String[] args) {
		SpringApplication.run(SpringBankAppApplication.class, args);
	}

	
	@Override
	public void run(String... args) throws Exception {
		accountDao.save(new Account("RAM", 12000.00, "9172625252", "RAM@gmail.com", "AAAAAAAAA", new Date()));
		accountDao.save(new Account("RAHIM", 10000.00, "9172625252", "RAHIM@gmail.com", "AAAAAAAAA", new Date()));
		accountDao.save(new Account("DAVID", 50000.00, "9172625252", "DAVID@gmail.com", "AAAAAAAAA", new Date()));
		
		
	}
}

package com.pradeep.bank.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.bank.model.Account;
import com.pradeep.bank.service.AccountService;

@RestController
public class BankRestController {

	@Autowired
	private AccountService accountService;

	@GetMapping("/transfer/{source}/{destination}/{amount}")
	public String fundTransfer(@PathVariable("source") int source, @PathVariable("destination") int destination,
			@PathVariable("amount") double amount) {

		accountService.fundTransfer(source, destination, amount);

		return "Account with id [" + source + "] is debited and Account with id [" + destination
				+ "] is credited by Rs " + amount + "/-";

	}
	
	@GetMapping("/accounts")
	public List<Account> fundTransfer() {

		return accountService.getAllAccounts();

		
	}
}

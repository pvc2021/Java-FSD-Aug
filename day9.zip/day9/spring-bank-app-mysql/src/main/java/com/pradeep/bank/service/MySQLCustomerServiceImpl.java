package com.pradeep.bank.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.bank.dao.CustomerDao;
import com.pradeep.bank.model.Customer;

@Service
//@Component("mapCustomerServiceImpl")
public class MySQLCustomerServiceImpl implements CustomerService{

	
	
	
	@Autowired 
	private CustomerDao customerDao; //dependency
	
	
	public MySQLCustomerServiceImpl() {
	System.out.println("===========MapCustomerServiceImpl created=============");
	}
	
	

	/*
	 * public MapCustomerServiceImpl(CustomerDao customerDao) //constructor
	 * injection { super(); this.customerDao = customerDao; System.out.
	 * println("===========MapCustomerServiceImpl param constructor=============");
	 * 
	 * }
	 * 
	 * 
	 * 
	 * public void setCustomerDao(CustomerDao customerDao)//setter injection {
	 * this.customerDao = customerDao; System.out.
	 * println("===========MapCustomerServiceImpl setCustomerDao============="); }
	 * 
	 */

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return   customerDao.save(customer)==customer;
				
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		
		if(customerDao.existsById(customer.getCustomerId()))
		  	return customerDao.save(customer)==customer;

		return false;
	
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if(customerDao.existsById(customerId))
		{
			customerDao.deleteById(customerId);
		return true;
		}
			
		return false;
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.findAll();
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findById(customerId).get();
	}
	

}

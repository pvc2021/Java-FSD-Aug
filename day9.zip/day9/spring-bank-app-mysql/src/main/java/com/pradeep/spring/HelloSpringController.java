package com.pradeep.spring;

import java.util.Date;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/spring")
public class HelloSpringController {

	
	public HelloSpringController() {
	System.out.println("############# Hello Spring Controller ################3");
	}


	@RequestMapping(value = "/hello",method = RequestMethod.GET)
	public String helloTest() {
		return "hello";
	}
	
	@RequestMapping("/welcome") //It supports all the methods
	public String welcomeTest() {
		return "welcome";
	}
	
	@RequestMapping("/greet") //It supports all the methods
	public String greetTest() {
		return "greet";
	}
	
	
	@RequestMapping("/hi")
	public ModelAndView hiTest() {
		return new ModelAndView("hi", "message","Hi all,Hope you are enjoying thr session");
	}
	
	
	@RequestMapping("today")
	public  @ResponseBody String todayTest() {
		return  "Hi All,Today is "+new Date();
				
	}
	
	
	
}


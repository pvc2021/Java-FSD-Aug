package com.pradeep.cms.ccc;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

import com.pradeep.cms.domain.Customer;


@Aspect
@Component
public class Logging {

	public Logging() {
	System.out.println("=============Logging created=============== ");
	}
	
	
	@Pointcut("execution(* com.pradeep.cms.service.ICustomerService.findCustomer(..))")
	private void select() {}
	
	@Pointcut("execution(* com.pradeep.cms.service.*.*(..))")
	private void selectAll() {}
	
	
	
	@Before("selectAll()")
	public void pbeforeAdvice() {
		System.err.println("########## Going to setUp Customer Profile ########### ");
	}
	
	@After("selectAll()")
	public void pafterAdvice() {
		System.err.println("########## setUp Customer Profile finished ########### ");
	}
	
	
	@AfterReturning(pointcut = "selectAll()",returning ="value")
	public void pafterReturningAdvice(Object value) {
		System.err.println("##########  Customer Returning  ########### "+value);
	}
	
	@AfterThrowing(pointcut ="selectAll()",throwing = "ex")
	public void pafterThrowingAdvice(Throwable ex) {
		System.err.println("##########  Customer throwing exception  ########### "+ex);
	}
	
	@Around("select()")
	public Object paroundAdvice(ProceedingJoinPoint joinPoint) {
		System.err.println("$$$$$$$$$$$ Customer around advice  $$$$$$$ ");
		
		Object value=null;
		
		
		try {
			System.err.println("$$$$$$$$$$$ Customer around : before proceed $$$$$$$ ");
			value=joinPoint.proceed();
			
			Customer c=(Customer)value;
			
			c.setName(c.getName().toUpperCase());
			c.setEmail(c.getEmail().toUpperCase());
				
			value=c;
			System.err.println("$$$$$$$$$$$ Customer around : after proceed $$$$$$$ ");
			
			
		} catch (Throwable e) {
				e.printStackTrace();
				System.err.println("$$$$$$$$$$$ Customer around : exception $$$$$$$ ");
				
			
		}
		
		System.err.println("$$$$$$$$$$$ Customer around : completed   $$$$$$$$$$ ");
		
		
		return value;
		
	}
	
}


First run container - Product Service
=====================================

docker run --name product --env RDS_URL=jdbc:h2:mem:pradeepdb --env RDS_DRIVER_CLASS=org.h2.Driver --env RDS_USERNAME=sa --env RDS_PASSWORD=password --env RDS_DIALECT=org.hibernate.dialect.H2Dialect -p 8080:8080 pradeepch82/prod:1.1

docker network ls
docker network inspect bridge
observe the ip address of container prdouct


Build docker image  for aws-consumer-service
============================================

docker build -t pradeepch82/aws-consumer-service:1.1 .

Running Container
===================
docker run --name consumer --env PRODUCT_SERVICE_URI=127.0.0.2:8080 --p 9995:9995 pradeepch82/aws-consumer-service:1.1


Push Image to docker hub
=========================
docker login
docker push @@@REPO_NAME/aws-consumer-service:1.1


Ex. docker push pradeepch82/aws-consumer-service:1.1
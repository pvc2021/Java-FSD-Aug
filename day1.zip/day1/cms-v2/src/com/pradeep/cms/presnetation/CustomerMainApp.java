package com.pradeep.cms.presnetation;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

import com.pradeep.cms.dao.MapCustomerDaoImpl;
import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerServiceImpl;
import com.pradeep.cms.service.ICustomerService;

public class CustomerMainApp {

	//Dependency
	private ICustomerService cs;

	public CustomerMainApp() {
		System.out.println("===========CustomerMainApp default constructor=========");

	}

	//Constructor Injection
	public CustomerMainApp(ICustomerService cs) {
		this.cs = cs;
		System.out.println("===========CustomerMainApp param constructor=========");

	}

	//setter Injection
	public void setCs(ICustomerService cs) {
		this.cs = cs;
		System.out.println("===========CustomerMainApp setCs =========");

	}

	public void addCustomer(Customer customer) {

		if (cs.saveCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] created successfully");
		else
			System.out.println("Problem In adding customer");

	}

	public void updateCustomer(Customer customer) {

		if (cs.updateCustomer(customer))
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] updated successfully");
		else
			System.out.println("Customer with Id [" + customer.getCustomerId() + "] deoesn't exist");

	}

	public void deleteCustomer(int customerId) {

		if (cs.deleteCustomer(customerId))
			System.out.println("Customer with Id [" + customerId + "] deleted successfully");
		else
			System.out.println("Customer with Id [" + customerId + "] deoesn't exist");

	}

	public void showCustomer(int customerId) {

		Customer customer = cs.findCustomer(customerId);

		if (customer != null)
			System.out.println("Customer with Id [" + customerId + "] Details \n\n" + customer);
		else
			System.out.println("Customer with Id [" + customerId + "] deoesn't exist");

	}

	public void showAllCustomers() {
		System.out.println("=================Customer Details====================");
		System.out.println("=====================================================");

		for (Customer c : cs.findAllCustomers())
			System.out.println(c);

	}
	
	
	
	
	public void myInit() {
		System.out.println("==========CustomerMainApp init method================");
	}
	
	public void myDestory() {
		System.out.println("==========CustomerMainApp destory method================");
	}
	
	
	
	
	public static void main(String[] args) {
		
	
	   //create a core container	
		
		//XmlBeanFactory c=new XmlBeanFactory(new ClassPathResource("beans.xml"));   
		
		//create advance container 
		
		ClassPathXmlApplicationContext c=new ClassPathXmlApplicationContext("beans.xml");
		
		System.out.println("Spring  container created");
			
		
	     //make a request to container for CustomerMainApp Bean
		 
		//use this version if there is only one bean of CustomerMainApp type
		//CustomerMainApp cma=c.getBean(CustomerMainApp.class);
		 
		
		  //use this version if there are multiple beans of  CustomerMainApp type
		CustomerMainApp cma1=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma2=(CustomerMainApp)c.getBean("customerMainApp");
		CustomerMainApp cma3=(CustomerMainApp)c.getBean("customerMainApp");
		   
		System.out.println(cma1);
		System.out.println(cma2);
		System.out.println(cma3);
		//cma.showAllCustomers();
		 		
		  
		//shutdown the container
		 c.registerShutdownHook();
		 
	
	}
}

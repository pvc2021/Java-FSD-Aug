package com.pradeep.springbootactivemqsubscriber;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootActivemqSubscriberApplicationTests {

	@Test
	void contextLoads() {
	}

}

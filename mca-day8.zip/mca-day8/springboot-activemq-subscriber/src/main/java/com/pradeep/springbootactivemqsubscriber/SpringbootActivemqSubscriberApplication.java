package com.pradeep.springbootactivemqsubscriber;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootActivemqSubscriberApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootActivemqSubscriberApplication.class, args);
	}

}

package com.pradeep.consumer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.pradeep.productservice.domain.Product;

@Service
@Scope("singleton")
public class ProductService {
	
@Autowired	
private RestTemplate restTemplate;	


@HystrixCommand(fallbackMethod ="fallbackMethodForProductById")
public Product getProductById(int productId) {
return restTemplate.getForObject("http://product-service/api/product-microservice/products/"+productId, Product.class);
}

public Product fallbackMethodForProductById(int productId) {
	return new Product(productId,"DELL",12000.00);
}

}
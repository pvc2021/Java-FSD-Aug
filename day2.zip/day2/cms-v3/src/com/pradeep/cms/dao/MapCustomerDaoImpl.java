package com.pradeep.cms.dao;

import java.util.ArrayList;
import java.util.List;

import com.pradeep.cms.data.CustomerMap;
import com.pradeep.cms.domain.Customer;

public class MapCustomerDaoImpl implements ICustomerDao {

	
	public MapCustomerDaoImpl() {
	System.out.println("============MapCustomerDaoImpl Created=============");
	}
	
	@Override
	public boolean saveCustomer(Customer customer) {
		return CustomerMap.INSTANCE.getMap().put(customer.getCustomerId(), customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		if (CustomerMap.INSTANCE.getMap().containsKey(customer.getCustomerId())) {
			return CustomerMap.INSTANCE.getMap().put(customer.getCustomerId(), customer) == customer;
		}

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if (CustomerMap.INSTANCE.getMap().containsKey(customerId)) {
			CustomerMap.INSTANCE.getMap().remove(customerId);
			return true;

		}

		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		return CustomerMap.INSTANCE.getMap().get(customerId);
	}

	@Override
	public List<Customer> findAllCustomers() {
		return new ArrayList<Customer>(CustomerMap.INSTANCE.getMap().values());
	}

}

package com.pradeep.cms.spring.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.ICustomerService;

@Controller
public class CustomerSpringController {

	@Qualifier("mySQLCustomerServiceImpl")
	@Autowired
	// Dependency
	private ICustomerService cs;

	@GetMapping("/getallcustomers")
	public ModelAndView getAllCustomers() {
		return new ModelAndView("customerList", "customers", cs.findAllCustomers());
	}

	@GetMapping("/new")
	public String newCustomer(ModelMap model) {

		model.addAttribute("customers",cs.findAllCustomers());
		model.addAttribute("customer",new Customer());
			
		return "addCustomer";
	}

	
	@GetMapping("/edit/{id}")
	public String newCustomer(@PathVariable("id") int customerId,ModelMap model) {

		model.addAttribute("customers",cs.findAllCustomers());
		model.addAttribute("customer",cs.findCustomer(customerId));
			
		return "editCustomer";
	}

	@PostMapping("/updatecustomer")
	public String updateCustomer( @ModelAttribute("customer") Customer customer ,ModelMap model) {

		cs.updateCustomer(customer);
		model.addAttribute("customers",cs.findAllCustomers());
			
		return "customerList";
	}

	@PostMapping("/addcustomer")
	public String addCustomer( @ModelAttribute("customer") Customer customer ,ModelMap model) {

		cs.saveCustomer(customer);
		
		model.addAttribute("customers",cs.findAllCustomers());
			
		return "customerList";
	}
	
	

	@GetMapping("/delete")
	public String deleteCustomer(@RequestParam("customerId")int customerId,  ModelMap model) {

		cs.deleteCustomer(customerId);
		
		model.addAttribute("customers",cs.findAllCustomers());
			
		return "customerList";
	}

}

package com.pradeep.cms.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerDao;
import com.pradeep.cms.domain.Customer;


@Service
//@Component  //mapCustomerServiceImpl
public class MapCustomerServiceImpl implements CustomerService{
	
	@Qualifier("mapCustomerDaoImpl")
	@Autowired
	//dependency
	private CustomerDao customerDao;
	
	public MapCustomerServiceImpl() {
	System.out.println("=====MapCustomerServiceImpl created=======");
	
	}
	
	



	

	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.saveCustomer(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.deleteCustomer(customerId);
	}

	@Override
	public Customer findCustomerById(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findCustomerById(customerId);
	}

	@Override
	public Collection<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.findAllCustomers();
	}

}

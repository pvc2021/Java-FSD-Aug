package com.pradeep.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.ICustomerDao;
import com.pradeep.cms.domain.Customer;

@Service
//@Component("customerServiceImpl")
public class MapCustomerServiceImpl implements ICustomerService {

	@Qualifier("mapCustomerDaoImpl")
	@Autowired
	//Dependency 
	private ICustomerDao customerDao;

	public MapCustomerServiceImpl() {
		System.out.println("======MySQLCustomerServiceImpl default constructor=====");
	}
/*
	//constructor injection
	public CustomerServiceImpl(ICustomerDao customerDao) {
		System.out.println("======CustomerServiceImpl param constructor=====");
		this.customerDao = customerDao;
	}

	
	
	@Qualifier("mySQLCustomerDaoImpl")
	@Autowired    //byType
	//setter injection
	public void setCustomerDao(ICustomerDao customerDao) {
		this.customerDao = customerDao;
		System.out.println("======CustomerServiceImpl setCustomerDao=====");
	}
*/
	@Override
	public boolean saveCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.saveCustomer(customer);
	}

	@Override
	public boolean updateCustomer(Customer customer) {
		// TODO Auto-generated method stub
		return customerDao.updateCustomer(customer);
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.deleteCustomer(customerId);
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return customerDao.findCustomer(customerId);
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return customerDao.findAllCustomers();
	}

}

package com.pradeep.cms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pradeep.cms.dao.CustomerRepository;
import com.pradeep.cms.domain.Customer;

@Service
public class MySQLRepositoryServiceImpl implements ICustomerService {

	@Autowired
	private CustomerRepository repository;

	@Override
	public boolean saveCustomer(Customer customer) {
		return repository.save(customer) == customer;
	}

	@Override
	public boolean updateCustomer(Customer customer) {

		
		if (repository.existsById(customer.getCustomerId()))
			return repository.save(customer) == customer;

		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		if (repository.existsById(customerId)) {
			repository.deleteById(customerId);
			return true;
		}

		return false;
	}

	@Override
	public Customer findCustomer(int customerId) {
		// TODO Auto-generated method stub
		return repository.findById(customerId).get();
	}

	@Override
	public List<Customer> findAllCustomers() {
		// TODO Auto-generated method stub
		return repository.findAll();
	}

}
